  <?php 
      $isPost = $_SERVER["REQUEST_METHOD"] == "POST";
      $ErrorSummary = "";
      $newURL = "regSuccess.html";
      if ($isPost) {
        include_once "dbconn.php";
        $informative = $_POST['group1'];
        $ease = $_POST['group2'];
        $experience = $_POST['group3'];
        $overallrating = $_POST['group4'];
        $name = $_POST['name'];
        $mobnum = $_POST['mobnum'];
        $addcomments = $_POST['addcomments'];
        
    if (empty(trim($name))) {
        $ErrorSummary = "Please enter your name.";
      }
      if (empty(trim($mobnum))) {
        $ErrorSummary = "Please enter your mobile number.";
      }
      if ($ErrorSummary == "") {
        $sql = "INSERT INTO feedback (informativeness,easeInNavigation,experienceRate,overallRating,name,mobNum,additionalComments)
         VALUES ('" . $informative . "', '" . $ease . "', '" . $experience . "', '" . $overallrating . "', '" . $name . "', '" . $mobnum . "', '" . $addcomments . "')";
      }
      if ($conn->query($sql) === TRUE) {
        header('Location: ' . $newURL);
      } else {
        $ErrorSummary = "Could not save";
      }
      $conn->close();

      }

     ?>