   <?php

    include_once "dbconn.php";
    $sql = "SELECT * FROM hospital Where 1=1 ";


    $sqlOrder = " ORDER BY srNo ASC ";
    $sqlFilters = "";


    try {
        //code...
        $area = isset($_GET['area']) ?  $_GET['area']: '';
        $hospitalname = isset($_GET['hospitalname']) ?  $_GET['hospitalname']: '';
        $charges = isset($_GET['charges']) ?  $_GET['charges']: '';
        $bed = isset($_GET['bed']) ?  $_GET['bed']: '';
   
      
        

        if (!(empty(trim($area)) && empty(trim($hospitalname)) && empty(trim($charges)) && empty(trim($bed)))) {

            if (!empty(trim($area))) {
                $sqlFilters .= " AND area ='" . $area . "'";
            }
            if (!empty(trim($hospitalname))) {
                $sqlFilters .= " AND hospitalName ='" . $hospitalname . "'";
            }
            if (!empty(trim($charges))) {
                $sqlFilters .= " AND charges ='" . $charges . "'";
            }
            if (!empty(trim($bed))) {
                // $sqlFilters .= " area ='" . $bed . "'";
            }
        }
    } catch (\Throwable $th) {
        throw $th;
    }




    $sql = $sql . $sqlFilters . $sqlOrder;


    // die($sql);

    $result = $conn->query($sql);




    ?>