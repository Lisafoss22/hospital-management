 <?php
  $isPost = $_SERVER["REQUEST_METHOD"] == "POST";
  $ErrorSummary = "";
  $newURL = "signupSuccess.html";
  if ($isPost) {
    include_once "dbconn.php";
    // collect value of input field
    $name = $_POST['username'];
    $pass = $_POST['pass'];
    $passAgain = $_POST['passAgain'];

    if ($pass != $passAgain) {
      $ErrorSummary = "Passwords donot match";
    }

    if ($ErrorSummary == "") {
      //Form Validated

      $sql = "INSERT INTO users (username, password) VALUES ('" . $name . "', '" . $pass . "')";

      if ($conn->query($sql) === TRUE) {
        header('Location: ' . $newURL);
      } else {
        $ErrorSummary = "Could not save";
      }
      $conn->close();
    }
  }
  ?>