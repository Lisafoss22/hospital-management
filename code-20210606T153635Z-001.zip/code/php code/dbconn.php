
<?php
$dbServername = "localhost";
$dbUSername = "root";
$dbPassword = "";
$dbName = "bedavail";

// Create connection
$conn = new mysqli($dbServername, $dbUSername, $dbPassword,$dbName);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>