
<script>
  function login(form, event) {
    event.preventDefault();
    var un = form.username.value;
    var pw = form.password.value;

    let formData = new FormData();
    formData.append('username', un);
    formData.append('password', pw);

    let xmlhttp = new XMLHttpRequest();

    xmlhttp.open("post", "loginApi.php", true);
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4) {

        let res = JSON.parse(this.response);

        if (xmlhttp.status == 200) {
          // alert("helo");
          location.href = "/bedavailability/";
        } else {
          document.getElementById("errorsummary").style.display = "block";
          document.getElementById("errorsummary").innerHTML = res.message;
        }
      }
    }

    xmlhttp.send(formData);

  }
</script>



<?php
$isPost = $_SERVER["REQUEST_METHOD"] == "POST";
$ErrorSummary = "";
$newURL = "index.html";

header('Content-Type: application/json');

if ($isPost) {
    include_once "dbconn.php";

    $name = $_POST['username'];
    $pass = $_POST['password'];

    if (empty(trim($name))) {
        $ErrorSummary = "Please enter username";
    }
    // Check if password is empty
    if (empty(trim($pass))) {
        $ErrorSummary .= ($ErrorSummary == "" ? "" : "</br>") .  "Please enter password.";
    }

    if ($ErrorSummary == "") {
        $sql = "SELECT id FROM users WHERE username = '$name' and password =  '$pass'";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            //login success
            //header('Location: ' . '/bedavailability/');


            $response = new \stdClass();
            $response->status = "success";
            $response->message = "login success";

            http_response_code(200);
        } else {
            // $ErrorSummary = "Username or password is incorrect";

            $response = new \stdClass();
            $response->status = "fail";
            $response->message = "Username or password is incorrect";

            http_response_code(401);
        }

        mysqli_close($conn);

        echo json_encode($response);

        // Close connection

    } else {

        $response = new \stdClass();
        $response->status = "validation";
        $response->message = trim($ErrorSummary);

        http_response_code(400);

        echo json_encode($response);
    }
}
