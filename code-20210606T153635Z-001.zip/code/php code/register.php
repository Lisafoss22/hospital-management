             <?php 
              $isPost = $_SERVER["REQUEST_METHOD"] == "POST";
              $ErrorSummary = "";
              $newURL = "regSuccess.html";
              if ($isPost) {
                  include_once "dbconn.php";
                    // collect value of input field
                    $fname = $_POST['firstName'];
                    $lname = $_POST['lastName'];
                    $age = $_POST['age'];
                    $gender = $_POST['gender'];
                    $hname = $_POST['hospitalName'];
                    $wardtype = $_POST['wardType'];
                    $bednum = $_POST['bedNum'];
                    $mobnum = $_POST['mobnum'];
                    $email = $_POST['email'];
                    if (empty(trim($fname))) {
                      $ErrorSummary = "Please enter firstName.";
                    }
                    if (empty(trim($lname))) {
                      $ErrorSummary = "Please enter lastName.";
                    }
                    if (empty(trim($age))) {
                      $ErrorSummary = "Please enter age.";
                    }
                    if (empty(trim($gender))) {
                      $ErrorSummary = "Please enter gender.";
                    }
                    if (empty(trim($hname))) {
                      $ErrorSummary = "Please enter hospitalName.";
                    }
                    if (empty(trim($wardtype))) {
                      $ErrorSummary = "Please enter wardType.";
                    }
                    if (empty(trim($bednum))) {
                      $ErrorSummary = "Please enter bedNum.";
                    }
                    if (empty(trim($mobnum))) {
                      $ErrorSummary = "Please enter mobnum.";
                    }
                    if (empty(trim($email))) {
                      $ErrorSummary = "Please enter email.";
                    }
                    if ($ErrorSummary == ""){
                      $sql = "INSERT INTO register (firstName,lastName,age,gender,hospitalName,wardType,noOfBed,mobNum,email) VALUES ('" . $fname . "', '" . $lname . "', '" . $age . "', '" . $gender . "', '" . $hname . "', '" . $wardtype . "', '" . $bednum . "', '" . $mobnum . "', '" . $email . "')";
                    }
                    if ($conn->query($sql) === TRUE) {
                      header('Location: ' . $newURL);
                    } else {
                      $ErrorSummary = "Could not save";
                    }
                    $conn->close();

              }
              ?>
